function miho_example

th_sac=15;
addpath('matcher');
tt=30;

clr=uint8(255*[...
    0 0.4470 0.7410; ...
    0.8500 0.3250 0.0980; ...
    0.9290 0.6940 0.1250; ...
    0.4940 0.1840 0.5560; ...
    0.4660 0.6740 0.1880; ...
    0.3010 0.7450 0.9330; ...
    0.6350 0.0780 0.1840; ...
]);

cd('matcher');
matches=hz('../miho1.jpg','../miho2.jpg');
[~,midx]=fun_sac_matrix(matches(:,[1 2]),matches(:,[3 4]),th_sac);
cd('..');    
good_matches=matches(midx,:);

Hdata=get_avg_hom(good_matches(:,[1 2]),good_matches(:,[3 4]),th_sac,fix(th_sac/2));
H=ransac_homography_(good_matches(:,[1 2]),good_matches(:,[3 4]),th_sac);

dd = [...
     1 1 1; ...
   -1  1 1; ...
    1 -1 1; ...
   -1 -1 1; ...
     ];

for i=1:4
    [~, D] = eig(H*diag(dd(i,:)));
    if all(sign(diag(D))>0)
        break;
    end
end

RR = diag(dd(i,:));

if det(H*RR) < 0
    hc = -1;
else
    hc = 1;
end

[V,D] = eig(H*RR*hc);
Hh = V*(D.^0.5)*inv(V);

Vdata{1}=Hh*RR*hc;
Vdata{2}=inv(Hh);

save('miho_matches.mat','good_matches','Hdata','H','Vdata');
% load('miho_matches.mat');

im1=imread('miho1.jpg');
im2=imread('miho2.jpg');

qb = ceil(min([size(im1,1), size(im1,2), size(im2,1), size(im2,2)]) / 10);

% im1 = make_grid(im1,qb);
% im2 = make_grid(im2,qb);

im1_mask=ones(size(im1,1),size(im1,2),'uint8');
im2_mask=ones(size(im2,1),size(im2,2),'uint8');

[im1_,im1_mask_]=show_transform(im1,Hdata{1},im2,Hdata{2});
[im2_,im2_mask_]=show_transform(im2,Hdata{2},im1,Hdata{1});

[im1v_,im1v_mask_]=show_transform(im1,Vdata{1},im2,Vdata{2});
[im2v_,im2v_mask_]=show_transform(im2,Vdata{2},im1,Vdata{1});

[im1a,im1a_mask]=show_transform(im1,H,im2,eye(3));
im2z=im2;
for i=1:3
    im2z(1:tt,:,i)=clr(1,i);
    im2z(end-tt+1:end,:,i)=clr(1,i);
    im2z(:,1:tt,i)=clr(1,i);
    im2z(:,end-tt+1:end,i)=clr(1,i);    
end
[im2a,im2a_mask]=show_transform(im2z,eye(3),im1,H);

im1z=im1;
for i=1:3
    im1z(1:tt,:,i)=clr(1,i);
    im1z(end-tt+1:end,:,i)=clr(1,i);
    im1z(:,1:tt,i)=clr(1,i);
    im1z(:,end-tt+1:end,i)=clr(1,i);    
end

[im1b,im1b_mask]=show_transform(im1z,eye(3),im2,inv(H));
[im2b,im2b_mask]=show_transform(im2,inv(H),im1,eye(3));

sz=max([size(im1v_); size(im2v_); size(im1_); size(im2_); size(im1a); size(im2a); size(im1b); size(im2b)]);

[b1_,m1_]=center_im(sz,im1_,im1_mask_);
[b2_,m2_]=center_im(sz,im2_,im2_mask_);
[c1_,d1_]=center_im(sz,im1a,im1a_mask);
[c2_,d2_]=center_im(sz,im2a,im2a_mask);
[e1_,f1_]=center_im(sz,im1b,im1b_mask);
[e2_,f2_]=center_im(sz,im2b,im2b_mask);
[v1_,q1_]=center_im(sz,im1v_,im1v_mask_);
[v2_,q2_]=center_im(sz,im2v_,im2v_mask_);


[e1_,f1_]=lborder(e1_,f1_,clr(2,:),tt);
[c1_,d1_]=lborder(c1_,d1_,clr(3,:),tt);
[b1_,m1_]=lborder(b1_,m1_,clr(4,:),tt);
[v1_,q1_]=lborder(v1_,q1_,clr(5,:),tt);


[e2_,f2_]=rborder(e2_,f2_,clr(2,:),tt);
[c2_,d2_]=rborder(c2_,d2_,clr(3,:),tt);
[b2_,m2_]=rborder(b2_,m2_,clr(4,:),tt);
[v2_,q2_]=rborder(v2_,q2_,clr(5,:),tt);

l1=cat(2,e1_,e2_);
l1_=cat(2,f1_,f2_);

l2=cat(2,c1_,c2_);
l2_=cat(2,d1_,d2_);

l3=cat(2,b1_,b2_);
l3_=cat(2,m1_,m2_);

l4=cat(2,v1_,v2_);
l4_=cat(2,q1_,q2_);

im=cat(1,l1,l2,l3,l4);
im_mask=cat(1,l1_,l2_,l3_,l4_);

imwrite(im,'miho.png','Alpha',im_mask*255);


function im = make_grid(im,qb)

    ci = 0;
    for i=1:qb:size(im,1)
        cj = 0;
        for j=1:qb:size(im,2)
            cc = mod(mod(ci,2)+mod(cj,2),2);
            im(i:min(i+qb-1,size(im,1)),j:min(j+qb-1,size(im,2)),:) = cc * 255;        
            cj = cj + 1;
        end
        ci = ci + 1;
    end


function [e1_,f1_]=lborder(e1_,f1_,clr,tt)

for i=1:3
    e1_(:,1:tt,i)=clr(i);
    e1_(~mod(fix((0:size(e1_,1)-1)/tt),2),end-fix(tt/2)+1:end,i)=clr(i);
    e1_(1:tt,:,i)=clr(i);
    e1_(end-tt+1:end,:,i)=clr(i);

    f1_(:,1:tt)=1;
    f1_(~mod(fix((0:size(f1_,1)-1)/tt),2),end-fix(tt/2)+1:end)=1;
    f1_(1:tt,:)=1;
    f1_(end-tt+1:end,:)=1;    
end


function [e1_,f1_]=rborder(e1_,f1_,clr,tt)

for i=1:3
    e1_(:,end-tt+1:end,i)=clr(i);
    e1_(~mod(fix((0:size(e1_,1)-1)/tt),2),1:fix(tt/2),i)=clr(i);
    e1_(1:tt,:,i)=clr(i);
    e1_(end-tt+1:end,:,i)=clr(i);

    f1_(:,end-tt+1:end)=1;
    f1_(~mod(fix((0:size(f1_,1)-1)/tt),2),1:fix(tt/2))=1;
    f1_(1:tt,:)=1;
    f1_(end-tt+1:end,:)=1;    
end


function [bim,bim_mask]=center_im(sz,im,im_mask)

bim=zeros(sz,'uint8');
bim_mask=zeros(sz(1:2),'uint8');

off=fix((sz-size(im))/2);
bim(1+off(1):size(im,1)+off(1),1+off(2):size(im,2)+off(2),:)=im;
bim_mask(1+off(1):size(im,1)+off(1),1+off(2):size(im,2)+off(2))=im_mask;


function [im_,im_mask]=show_transform(im,H,im_aux,H_aux)

sz=size(im);
if length(sz)==2
    im=reshape(im,[sz 1]);
    sz=[sz 1];
end

b=[...
        0     0 1;...
    sz(2)     0 1;...
       0  sz(1) 1;...
    sz(2) sz(1) 1;...
    ]';

b_=H*b;
b_=b_';
b_=b_./repmat(b_(:,3),[1 3]);


sz_=size(im_aux);
if length(sz_)==2
    im=reshape(im,[sz_ 1]);
    sz_=[sz_ 1];
end

b_aux=[...
        0     0 1;...
    sz_(2)     0 1;...
       0  sz_(1) 1;...
    sz_(2) sz_(1) 1;...
    ]';

b_aux_=H_aux*b_aux;
b_aux_=b_aux_';
b_aux_=b_aux_./repmat(b_aux_(:,3),[1 3]);


if any(~isfinite(b_aux_(:)))
    disp('warning!');
end

b_=[b_; b_aux_];

c=[floor(min(b_)); ceil(max(b_))];
sz_=[c(2,2)-c(1,2) c(2,1)-c(1,1)];
% if max(sz_)>2048
%     s_=1024/max(sz_);
%     disp('reduction');
% else
    s_=1;
% end
sz_=round(sz_*s_);
sz_=[sz_ sz(3)];

T=[s_ 0  0;...
   0  s_ 0;...
   0  0  1] * ...
  [1 0 -c(1,1);...
   0 1 -c(1,2);...
   0 0       1];

H_=T*H;
H_inv=inv(H_);

im_=zeros(sz_);
im_mask=ones(sz_(1:2),'uint8');
for x_=1:sz_(2)
    for y_=1:sz_(1)
        pt=H_inv*[x_ y_ 1]';
        x=pt(1)/pt(3);
        y=pt(2)/pt(3);

        xf=floor(x);
        yf=floor(y);
        xc=xf+1;
        yc=yf+1;
        
        if (xf<1)||(xc>sz(2))||(yf<1)||(yc>sz(1))
            im_mask(y_,x_)=0;
            continue;
        end
        
        for c=1:sz_(3)            
            im_(y_,x_,c)=...
                im(yf,xf,c)*(xc-x)*(yc-y)+...
                im(yc,xc,c)*(x-xf)*(y-yf)+...            
                im(yf,xc,c)*(x-xf)*(yc-y)+...                        
                im(yc,xf,c)*(xc-x)*(y-yf)+...
                0;
        end
    end
end

im_=squeeze(uint8(im_));


function Hdata=get_avg_hom(pt1,pt2,th,th_out)

H1=eye(3);
H2=eye(3);

max_iter=5;
midx=zeros(1,size(pt1,1));

pt1_=pt1(~midx,:);
pt1_=[pt1_ ones(size(pt1_,1),1)]';
pt1_=H1*pt1_;
pt1_=pt1_(1:2,:)./repmat(pt1_(3,:),[2 1]);

pt2_=pt2(~midx,:);
pt2_=[pt2_ ones(size(pt2_,1),1)]';
pt2_=H2*pt2_;
pt2_=pt2_(1:2,:)./repmat(pt2_(3,:),[2 1]);
    
[H1_,H2_,nidx]=ransac_middle(pt1_',pt2_',th,th_out);

zidx=zeros(1,size(midx,2),'logical');
zidx(~midx)=nidx;

H1_new=H1_*H1;
H2_new=H2_*H2;
for i=1:max_iter    
    pt1_=pt1(zidx,:);
    pt1_=[pt1_ ones(size(pt1_,1),1)]';
    pt1_=H1_new*pt1_;
    pt1_=pt1_./repmat(pt1_(3,:),[3 1]);
    
    pt2_=pt2(zidx,:);
    pt2_=[pt2_ ones(size(pt2_,1),1)]';
    pt2_=H2_new*pt2_;
    pt2_=pt2_./repmat(pt2_(3,:),[3 1]);

    ptm=(pt1_+pt2_)/2;
    H1_=compute_homography(pt1_,ptm);
    H2_=compute_homography(pt2_,ptm);

    H1_new=H1_*H1_new;
    H2_new=H2_*H2_new;
end

Hdata={H1_new, H2_new, zidx};


function [H1,H2,midx,oidx,c]=ransac_middle(pt1,pt2,th,th_out)

warning('off','MATLAB:nearlySingularMatrix');
warning('off','MATLAB:nchoosek:LargeCoefficient');

% th=3;
max_iter=10000;
min_iter=100;
p=0.9;
c=0;

n=size(pt1,1);
th=th^2;
th_out=th_out^2;

if n<4
    H1=[];
    H2=[];
    midx=zeros(1,n,'logical');
    oidx=zeros(1,n,'logical');    
    return;
end

min_iter=min(min_iter,nchoosek(n,2));

pt1=[pt1 ones(n,1)]';
pt2=[pt2 ones(n,1)]';

midx=zeros(1,n,'logical');
oidx=zeros(1,n,'logical');
Nc=inf;
for c=1:max_iter    
    sidx=randperm(n,4);
    ptm=(pt1+pt2)/2;
    [H1,eD]=compute_homography(pt1(:,sidx),ptm(:,sidx));
    if eD(end-1)<0.05
        continue;
    end    
    [H2,eD]=compute_homography(pt2(:,sidx),ptm(:,sidx));
    if eD(end-1)<0.05
        continue;
    end    

    nidx=get_hom_inliers(pt1,ptm,H1,th,sidx)&get_hom_inliers(pt2,ptm,H2,th,sidx);
    if sum(nidx)>sum(midx)
        midx=nidx;
        sidx_=sidx;
        Nc=steps(4,sum(midx)/numel(midx),p);
    end
    if (c>Nc)&&(c>min_iter)
        break;
    end
end
if any(midx)
    H1=compute_homography(pt1(:,midx),ptm(:,midx));
    H2=compute_homography(pt2(:,midx),ptm(:,midx));
    midx=get_hom_inliers(pt1,ptm,H1,th,sidx_)&get_hom_inliers(pt2,ptm,H2,th,sidx_);
    oidx=get_hom_inliers(pt1,ptm,H1,th_out,sidx_)&get_hom_inliers(pt2,ptm,H2,th_out,sidx_);
else
    H1=[];
    H2=[];
    midx=zeros(1,n,'logical');
    oidx=zeros(1,n,'logical');    
    return;
end

warning('on','MATLAB:nearlySingularMatrix');
warning('on','MATLAB:nchoosek:LargeCoefficient');


function [H,D]=compute_homography(pts1,pts2)

T1=data_normalize(pts1);
T2=data_normalize(pts2);

npts1=T1*pts1;
npts2=T2*pts2;

l=size(npts1,2);
A=[zeros(l,3) -repmat(npts2(3,:)',[1 3]).*npts1' repmat(npts2(2,:)',[1 3]).*npts1';...
    repmat(npts2(3,:)',[1 3]).*npts1' zeros(l,3) -repmat(npts2(1,:)',[1 3]).*npts1';...
    -repmat(npts2(2,:)',[1 3]).*npts1' repmat(npts2(1,:)',[1 3]).*npts1' zeros(l,3)];
[~,D,V]=svd(A);
D=diag(D);
H=reshape(V(:,9),[3 3])';
H=T2\H*T1;


function T=data_normalize(pts)

c=mean(pts,2);
s=sqrt(2)/mean(sqrt((pts(1,:)-c(1)).^2+(pts(2,:)-c(2)).^2));
T=[s 0 -c(1)*s; 0 s -c(2)*s; 0 0 1];


function [nidx,err]=get_hom_inliers(pt1,pt2,H,th,sidx)

pt2_=H*pt1;
s2_=sign(pt2_(3,:));
tmp2_=pt2_(1:2,:)./repmat(pt2_(3,:),[2 1])-pt2(1:2,:);
err2=sum(tmp2_.^2);
s2=s2_(sidx(1));
if ~all(s2_(sidx)==s2)
    nidx=zeros(1,size(pt1,2),'logical');
    err=inf;
    return;
end

pt1_=H\pt2;
s1_=sign(pt1_(3,:));
tmp1_=pt1_(1:2,:)./repmat(pt1_(3,:),[2 1])-pt1(1:2,:);
err1=sum(tmp1_.^2);

s1=s1_(sidx(1));
if ~all(s1_(sidx)==s1)
    nidx=zeros(1,size(pt1,2),'logical');
    err=inf;
    return;
end

err=max([err1; err2]);
err(~isfinite(err))=inf;
nidx=(err<th)&(s2_==s2)&(s1_==s1);


function r=steps(pps,inl,p)

e=1-inl;
r=log(1-p)/log(1-(1-e)^pps);


function [H,D]=compute_homography_(pts1,pts2)

T1=data_normalize_(pts1);
T2=data_normalize_(pts2);

npts1=T1*pts1;
npts2=T2*pts2;

l=size(npts1,2);
A=[zeros(l,3) -repmat(npts2(3,:)',[1 3]).*npts1' repmat(npts2(2,:)',[1 3]).*npts1';...
    repmat(npts2(3,:)',[1 3]).*npts1' zeros(l,3) -repmat(npts2(1,:)',[1 3]).*npts1';...
    -repmat(npts2(2,:)',[1 3]).*npts1' repmat(npts2(1,:)',[1 3]).*npts1' zeros(l,3)];
[~,D,V]=svd(A);
D=diag(D);
H=reshape(V(:,9),[3 3])';
H=T2\H*T1;


function T=data_normalize_(pts)

c=mean(pts,2);
s=sqrt(2)/mean(sqrt((pts(1,:)-c(1)).^2+(pts(2,:)-c(2)).^2));
T=[s 0 -c(1)*s; 0 s -c(2)*s; 0 0 1];


function [H,midx,c]=ransac_homography_(pt1,pt2,th)

warning('off','MATLAB:nearlySingularMatrix');
warning('off','MATLAB:nchoosek:LargeCoefficient');

% th=3;
max_iter=10000;
min_iter=100;
p=0.9;
c=0;

n=size(pt1,1);
th=th^2;

if n<4
    H=[];
    midx=zeros(1,n,'logical');
    return;
end

min_iter=min(min_iter,nchoosek(n,4));

pt1=[pt1 ones(n,1)]';
pt2=[pt2 ones(n,1)]';

midx=zeros(1,n,'logical');
H=[];
Nc=inf;
for c=1:max_iter    
    sidx=randperm(n,4);
    [H,eD]=compute_homography_(pt1(:,sidx),pt2(:,sidx));
    if eD(end-1)<0.05
        continue;
    end    
    nidx=get_inliers_(pt1,pt2,H,th,sidx);
    if sum(nidx)>sum(midx)
        midx=nidx;
        sidx_=sidx;
        Nc=steps_(4,sum(midx)/numel(midx),p);
    end
    if (c>Nc)&&(c>min_iter)
        break;
    end
end
if any(midx)
    H=compute_homography_(pt1(:,midx),pt2(:,midx));
    midx=get_inliers_(pt1,pt2,H,th,sidx_);
end

warning('on','MATLAB:nearlySingularMatrix');
warning('on','MATLAB:nchoosek:LargeCoefficient');


function nidx=get_inliers_(pt1,pt2,H,th,sidx)

pt2_=H*pt1;
s2_=sign(pt2_(3,:));
tmp2_=pt2_(1:2,:)./repmat(pt2_(3,:),[2 1])-pt2(1:2,:);
err2=sum(tmp2_.^2);
s2=s2_(sidx(1));
if ~all(s2_(sidx)==s2)
    nidx=zeros(1,size(pt1,2),'logical');
    return;
end

pt1_=H\pt2;
s1_=sign(pt1_(3,:));
tmp1_=pt1_(1:2,:)./repmat(pt1_(3,:),[2 1])-pt1(1:2,:);
err1=sum(tmp1_.^2);

s1=s1_(sidx(1));
if ~all(s1_(sidx)==s1)
    nidx=zeros(1,size(pt1,2),'logical');
    return;
end

err=max([err1; err2]);
err(~isfinite(err))=inf;
nidx=(err<th)&(s2_==s2)&(s1_==s1);


function r=steps_(pps,inl,p)

e=1-inl;
r=log(1-p)/log(1-(1-e)^pps);

