function thumb_png(data_dir)

d=dir(data_dir);
d=d([d(:).isdir]);
d=d(3:end);
l=400;
b=7;
c=uint8(255*[...
    0 0.4470 0.7410; ...
    0.8500 0.3250 0.0980; ...
    0.9290 0.6940 0.1250; ...
    0.4940 0.1840 0.5560; ...
    0.4660 0.6740 0.1880; ...
    0.3010 0.7450 0.9330; ...
    0.6350 0.0780 0.1840; ...
]);
max_col=l*8;

im_all=zeros(0,max_col,3,'uint8');
im_all_mask=zeros(0,max_col,'uint8');
im_row=zeros(l,0,3,'uint8');
im_row_mask=zeros(l,0,'uint8');
for i=1:length(d)
    im1s=[data_dir filesep d(i).name filesep 'img1.jpg'];
    im2s=[data_dir filesep d(i).name filesep 'img2.jpg'];
    im1=imresize(imread(im1s),[l nan]);
    im2=imresize(imread(im2s),[l nan]);
    for j=1:3
        cc=c(mod(i-1,size(c,1))+1,j);        
        
        im1(:,1:b*2,j)=cc;
        im1(~mod(fix((0:size(im1,1)-1)/b),2),end-b+1:end,j)=cc;
        im1(1:b*2,:,j)=cc;
        im1(end-b*2+1:end,:,j)=cc;

        im2(~mod(fix((0:size(im2,1)-1)/b),2),1:b*2,j)=cc;
        im2(:,end-b*2+1:end,j)=cc;
        im2(1:b*2,:,j)=cc;
        im2(end-b*2+1:end,:,j)=cc;
    end
    im=cat(2,im1,im2);
    im_mask=ones(size(im,1:2));

    if size(im_row,2)+size(im,2)>=max_col
        im_row=cat(2,im_row,zeros(l,max_col-size(im_row,2),3,'uint8'));
        im_row_mask=cat(2,im_row_mask,zeros(l,max_col-size(im_row_mask,2),'uint8'));

        im_all=cat(1,im_all,im_row);
        im_all_mask=cat(1,im_all_mask,im_row_mask);

        im_row=zeros(l,0,3,'uint8');
        im_row_mask=zeros(l,0,'uint8');
    end

    im_row=cat(2,im_row,im);
    im_row_mask=cat(2,im_row_mask,im_mask);
end

if ~isempty(im_row)
    im_row=cat(2,im_row,zeros(l,max_col-size(im_row,2),3));
    im_row_mask=cat(2,im_row_mask,zeros(l,max_col-size(im_row_mask,2)));

    im_all=cat(1,im_all,im_row);
    im_all_mask=cat(1,im_all_mask,im_row_mask);    
end

c=find(~sum(im_all_mask),1);
if ~isempty(c)
    im_all_mask=im_all_mask(:,1:c);
    im_all=im_all(:,1:c,:);
end

imwrite(im_all,'dataset_thumb.png','Alpha',im_all_mask*255);