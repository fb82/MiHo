function show_miho_planes

clr=uint8(255*[...
    0 0.4470 0.7410; ...
    0.8500 0.3250 0.0980; ...
    0.9290 0.6940 0.1250; ...
    0.4940 0.1840 0.5560; ...
    0.4660 0.6740 0.1880; ...
    0.3010 0.7450 0.9330; ...
    0.6350 0.0780 0.1840; ...
]);

s=0.2;
dpath='data_old';
% what='keynet';
th_sac=15;
th_cf=2;

p=dir([dpath filesep '*']);
p_valid=[p.isdir];
p_valid(1:2)=0;
p=p(p_valid);
addpath('matcher');

method={...
    'keynet',          @keynet; ...
    'keynet_upright',  @keynet_upright; ...
    'hz',              @hz; ...
    'hz_upright',      @hz_upright; ...    
    };

corr_method={...
    'lsm',        @lsm; ...
    'norm_corr',  @ncorr; ...
    'fast_match', @fmatch; ...
    };

err=11;
e=[];
for k=1:err
    if mod(k,2)
        e=[e; k*[0 1; 1 0; 0 -1; -1 0]];
    else
        e=[e; k*[1 1; 1 -1; -1 1; -1 -1]];
    end
end

z=3;
widx=z;
%   widx=find(strcmp(method(:,1),what));
i=11;
bpath=[dpath filesep p(i).name];
ppath=[dpath filesep p(i).name filesep 'working_' method{widx,1}];

im1l_name=[ppath filesep 'img1_scale_' num2str(s) '.png'];
im2l_name=[ppath filesep 'img2_scale_' num2str(s) '.png'];

gt_file=[bpath filesep 'gt.mat'];
gt=load(gt_file);
gt=gt.gt;

match_file=[ppath filesep 'matches_scale_' num2str(s) '_' method{widx,1} '_sac_' num2str(th_sac) '.mat'];
matches=load(match_file);
midx=matches.midx;
matches=matches.matches;

gt_scaled=gt*s;

mm1=pdist2(matches(:,1:2),gt_scaled(:,1:2));
mm2=pdist2(matches(:,3:4),gt_scaled(:,3:4));
to_remove_matches=any(mm1<th_sac*th_cf,2)|any(mm2<th_sac*th_cf,2);
hom_matches=matches(~to_remove_matches,:);

k=1;
aux=gt_scaled;
all_matches=[aux; hom_matches];

middle_homo_file=[ppath filesep 'matches_scale_' num2str(s) '_' method{widx,1} '_sac_' num2str(th_sac) '_err_' num2str(e(k,1)) '_' num2str(e(k,2))  '_middle_homo.mat'];
Hdata=load(middle_homo_file);
didx=Hdata.didx;
Hdata=Hdata.Hdata;

to_check_matches=all_matches(1:size(gt_scaled,1),:);
hom_data.Hdata=Hdata;
hom_data.didx=didx(1:size(gt_scaled,1));

mark={'o','d','s'};
ll={'-',':','--'};

gidx=[ones(1,size(gt_scaled,1)) zeros(1,size(hom_matches,1))]>0;

h=figure;
im1=imread(im1l_name);
im2=imread(im2l_name);
sz=size(im1,1);

clr_=clr(end,:);

tt=20;

for i=1:3
    im1(1:tt,:,i)=clr_(i);
    im1(end-fix(tt/2)+1:end,~mod(fix((0:size(im1,2)-1)/tt),2),i)=clr_(i);
    im1(:,1:tt,i)=clr_(i);
    im1(:,end-tt+1:end,i)=clr_(i);
end

for i=1:3
    im2(end-tt+1:end,:,i)=clr_(i);
    im2(1:fix(tt/2),~mod(fix((0:size(im2,2)-1)/tt),2),i)=clr_(i);
    im2(:,1:tt,i)=clr_(i);
    im2(:,end-tt+1:end,i)=clr_(i);
end

im=cat(1,im1,im2);
imshow(im);
hold on;
for i=1:size(Hdata,1)
    q=mod((i-1),size(clr,1))+1;    
    plot(all_matches(didx==i,1),all_matches(didx==i,2),mark{fix((i-1)/size(clr,1))+1},...
        'MarkerEdgeColor',clr(q,:), ...
        'MarkerFaceColor',clr(q,:), ...
        'MarkerSize', 6 ...        
        );

    plot(all_matches((didx==i)&gidx,1),all_matches((didx==i)&gidx,2),'o',...
        'MarkerEdgeColor','k', ...
        'MarkerSize', th_sac*2, ...
        'LineWidth', 2 ...        
        );    

    plot(all_matches(didx==i,3),all_matches(didx==i,4)+sz,mark{fix((i-1)/size(clr,1))+1},...
        'MarkerEdgeColor',clr(q,:), ...
        'MarkerFaceColor',clr(q,:), ...
        'MarkerSize', 6 ...        
        );

    plot(all_matches((didx==i)&gidx,3),all_matches((didx==i)&gidx,4)+sz,'o',...
        'MarkerEdgeColor','k', ...
        'MarkerSize', th_sac*2, ...
        'LineWidth', 2 ...
        );    
end

saveas(h,'out.svg');
close(h);
system('export LD_LIBRARY_PATH= && rsvg-convert -f pdf out.svg > out_.pdf');
system('export LD_LIBRARY_PATH= && pdfcrop out_.pdf miho_plane.pdf');
delete('out_.pdf');
delete('out.svg');
