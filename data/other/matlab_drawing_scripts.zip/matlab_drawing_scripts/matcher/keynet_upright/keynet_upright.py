import cv2
import kornia as K
import kornia.feature as KF
import numpy as np
import torch
import argparse
from kornia_moons.feature import *
import scipy.io as sio
import warnings

def load_torch_image(fname):
    img = K.image_to_tensor(cv2.imread(fname), False).float() /255.
    img = K.color.bgr_to_rgb(img)
    return img

def get_matching_keypoints(lafs1, lafs2, idxs):
    mkpts1 = KF.get_laf_center(lafs1).squeeze()[idxs[:,0]].detach().cpu().numpy()
    mkpts2 = KF.get_laf_center(lafs2).squeeze()[idxs[:,1]].detach().cpu().numpy()
    return mkpts1, mkpts2

if __name__ == '__main__':
    warnings.filterwarnings("ignore", category=UserWarning)   
    parser = argparse.ArgumentParser(
        description='demo',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--input_1st', type=str, help="1st image.")
    parser.add_argument('--input_2nd', type=str, help="2nd image.")
    parser.add_argument('--output_file', type=str, default='keynet_upright.mat', help=".mat file to save matches.")

    opt = parser.parse_args()

    device = torch.device('cpu')
    device = K.utils.get_cuda_device_if_available()

    fname1 = opt.input_1st
    fname2 = opt.input_2nd

    img1 = load_torch_image(fname1).to(device)
    img2 = load_torch_image(fname2).to(device)

    feature = KF.KeyNetAffNetHardNet(8000, True).eval().to(device)

    input_dict = {"image0": K.color.rgb_to_grayscale(img1),
                  "image1": K.color.rgb_to_grayscale(img2)}

    hw1 = torch.tensor(img1.shape[2:])
    hw2 = torch.tensor(img2.shape[2:])

    adalam_config = {"device": device}

    with torch.inference_mode():
        lafs1, resps1, descs1 = feature(K.color.rgb_to_grayscale(img1))
        lafs2, resps2, descs2 = feature(K.color.rgb_to_grayscale(img2))
        dists, idxs = KF.match_adalam(descs1.squeeze(0), descs2.squeeze(0),
                                      lafs1, lafs2, # Adalam takes into account also geometric information
                                      config=adalam_config,
                                      hw1=hw1, hw2=hw2) # Adalam also benefits from knowing image size

    mkpts1, mkpts2 = get_matching_keypoints(lafs1, lafs2, idxs)

    dict_to_save = {}        
    dict_to_save['kpt1'] = mkpts1
    dict_to_save['kpt2'] = mkpts2
    dict_to_save['conf'] = dists    
    
    sio.savemat(opt.output_file,dict_to_save)
