function [F,midx,c,H]=fun_sac_matrix(pt1,pt2,th)

warning('off','MATLAB:nearlySingularMatrix');
warning('off','MATLAB:nchoosek:LargeCoefficient');

% th=3;
max_iter=10000;
min_iter=200;
p=0.9;
c=0;
c_=0;

n=size(pt1,1);
th=th^2;

if n<8
    F=[];
    midx=zeros(1,n,'logical');
    return;
end

min_iter=min(min_iter,nchoosek(n,8));

pt1=[pt1 ones(n,1)]';
pt2=[pt2 ones(n,1)]';

midx=zeros(1,n,'logical');
midx_=zeros(1,n,'logical');
hidx=zeros(1,n,'logical');
H=[];
F=[];
Nc=inf;
for c=1:max_iter    
    sidx=randperm(n,8);
    [F,eD]=fun_matrix(pt1(:,sidx),pt2(:,sidx));
    if eD(end)<0.05
        [H,eD_]=compute_homography(pt1(:,sidx),pt2(:,sidx));
        if eD_(end-1)<0.05
            continue;
        end
        aidx=get_inliers(pt1,pt2,H,th,sidx);
        if sum(aidx)>sum(hidx)
            hidx=aidx;
            sidx_=sidx;
            Nc=steps(8,sum(hidx)/numel(hidx),p);
            if (c>Nc)&&(c>min_iter)
                break;
            end
        end
        continue;
    end    
    nidx=get_epi_inliers(pt1,pt2,F,th);
    if sum(nidx)>sum(midx)
        midx=nidx;
        Nc=steps(8,sum(midx)/numel(midx),p);
    end
    if (c>Nc)&&(c>min_iter)
        break;
    end
end
if any(midx)
    F=fun_matrix(pt1(:,midx),pt2(:,midx));
    % H=compute_homography(pt1(:,midx),pt2(:,midx));
    midx=get_epi_inliers(pt1,pt2,F,th);
end
if sum(hidx)>4
    H=compute_homography(pt1(:,hidx),pt2(:,hidx));
    aidx=get_inliers(pt1,pt2,H,th,sidx_);
    [F_,~,c_]=fun_sac_from_plane(H,pt1(:,~aidx),pt2(:,~aidx),th,pt1(:,aidx),pt2(:,aidx));
    if ~isempty(F_)
        midx_=get_epi_inliers(pt1,pt2,F_,th);
    end
end
c=[c c_];
if sum(midx_)>sum(midx)
    F=F_;
    midx=midx_;
end

warning('on','MATLAB:nearlySingularMatrix');
warning('on','MATLAB:nchoosek:LargeCoefficient');


function [H,D]=compute_homography(pts1,pts2)

T1=data_normalize(pts1);
T2=data_normalize(pts2);

npts1=T1*pts1;
npts2=T2*pts2;

l=size(npts1,2);
A=[zeros(l,3) -repmat(npts2(3,:)',[1 3]).*npts1' repmat(npts2(2,:)',[1 3]).*npts1';...
    repmat(npts2(3,:)',[1 3]).*npts1' zeros(l,3) -repmat(npts2(1,:)',[1 3]).*npts1';...
    -repmat(npts2(2,:)',[1 3]).*npts1' repmat(npts2(1,:)',[1 3]).*npts1' zeros(l,3)];
[~,D,V]=svd(A);
D=diag(D);
H=reshape(V(:,9),[3 3])';
H=T2\H*T1;


function T=data_normalize(pts)

c=mean(pts,2);
s=sqrt(2)/mean(sqrt((pts(1,:)-c(1)).^2+(pts(2,:)-c(2)).^2));
T=[s 0 -c(1)*s; 0 s -c(2)*s; 0 0 1];


function [H,midx,c]=ransac_homography(pt1,pt2,th)

warning('off','MATLAB:nearlySingularMatrix');
warning('off','MATLAB:nchoosek:LargeCoefficient');

% th=3;
max_iter=10000;
min_iter=100;
p=0.9;
c=0;

n=size(pt1,1);
th=th^2;

if n<4
    H=[];
    midx=zeros(1,n,'logical');
    return;
end

min_iter=min(min_iter,nchoosek(n,4));

pt1=[pt1 ones(n,1)]';
pt2=[pt2 ones(n,1)]';

midx=zeros(1,n,'logical');
H=[];
Nc=inf;
for c=1:max_iter    
    sidx=randperm(n,4);
    [H,eD]=compute_homography(pt1(:,sidx),pt2(:,sidx));
    if eD(end-1)<0.05
        continue;
    end    
    nidx=get_inliers(pt1,pt2,H,th,sidx);
    if sum(nidx)>sum(midx)
        midx=nidx;
        sidx_=sidx;
        Nc=steps(4,sum(midx)/numel(midx),p);
    end
    if (c>Nc)&&(c>min_iter)
        break;
    end
end
if any(midx)
    H=compute_homography(pt1(:,midx),pt2(:,midx));
    midx=get_inliers(pt1,pt2,H,th,sidx_);
end

warning('on','MATLAB:nearlySingularMatrix');
warning('on','MATLAB:nchoosek:LargeCoefficient');


function nidx=get_inliers(pt1,pt2,H,th,sidx)

pt2_=H*pt1;
s2_=sign(pt2_(3,:));
tmp2_=pt2_(1:2,:)./repmat(pt2_(3,:),[2 1])-pt2(1:2,:);
err2=sum(tmp2_.^2);
s2=s2_(sidx(1));
if ~all(s2_(sidx)==s2)
    nidx=zeros(1,size(pt1,2),'logical');
    return;
end

pt1_=H\pt2;
s1_=sign(pt1_(3,:));
tmp1_=pt1_(1:2,:)./repmat(pt1_(3,:),[2 1])-pt1(1:2,:);
err1=sum(tmp1_.^2);

s1=s1_(sidx(1));
if ~all(s1_(sidx)==s1)
    nidx=zeros(1,size(pt1,2),'logical');
    return;
end

err=max([err1; err2]);
err(~isfinite(err))=inf;
nidx=(err<th)&(s2_==s2)&(s1_==s1);


function r=steps(pps,inl,p)

e=1-inl;
r=log(1-p)/log(1-(1-e)^pps);

function [F,D_]=fun_matrix(pts1,pts2)

T1=data_normalize(pts1);
T2=data_normalize(pts2);

npts1=T1*pts1;
npts2=T2*pts2;

A=[...
    npts2(1,:)'.*npts1(1,:)' npts2(1,:)'.*npts1(2,:)' npts2(1,:)' ...
    npts2(2,:)'.*npts1(1,:)' npts2(2,:)'.*npts1(2,:)' npts2(2,:)' ...
    npts1(1,:)'              npts1(2,:)'              ones(size(npts1,2),1) ...
    ];       

[~,D_,V]=svd(A);
D_=diag(D_);
F=reshape(V(:,9),[3 3])';
[U,D,V]=svd(F);
F=U*diag([D(1,1) D(2,2) 0])*V';

F = T2'*F*T1;


function e=get_epi_dist(pts1,pts2,F)

aux1=F*pts1;
e=abs(sum(aux1.*pts2))./((aux1(1,:).^2+aux1(2,:).^2).^0.5);


function nidx=get_epi_inliers(pt1,pt2,F,th)

err1=get_epi_dist(pt1,pt2,F);
err2=get_epi_dist(pt2,pt1,F');

err=max([err1; err2]);
err(~isfinite(err))=inf;
nidx=(err<th);


function [F,midx,c]=fun_sac_from_plane(H,pt1,pt2,th,pt1_,pt2_)

warning('off','MATLAB:nearlySingularMatrix');
warning('off','MATLAB:nchoosek:LargeCoefficient');

% th=3;
max_iter=10000;
min_iter=50;
p=0.9;
c=0;

n=size(pt1,2);

if n<2
    F=[];
    midx=zeros(1,n,'logical');
    return;
end

min_iter=min(min_iter,nchoosek(n,2));

midx=zeros(1,n,'logical');
F=[];
Nc=inf;
for c=1:max_iter    
    sidx=randperm(n,2);
    tmp=H*pt1(:,sidx);
    tmp=tmp./repmat(tmp(3,:),[3 1]);
    l1=cross(tmp(:,1),pt2(:,sidx(1)));
    l2=cross(tmp(:,2),pt2(:,sidx(2)));
    e_=cross(l1,l2);
    e_=e_/e_(3);
    F=[0 -e_(3) e_(2); e_(3) 0 -e_(1); -e_(2) e_(1) 0]*H;
    nidx=get_epi_inliers(pt1,pt2,F,th);
    if sum(nidx)>sum(midx)
        midx=nidx;
        Nc=steps(2,sum(midx)/numel(midx),p);
    end
    if (c>Nc)&&(c>min_iter)
        break;
    end
end
if any(midx)
    F=fun_matrix([pt1(:,midx) pt1_],[pt2(:,midx) pt2_]);
end

warning('on','MATLAB:nearlySingularMatrix');
warning('on','MATLAB:nchoosek:LargeCoefficient');
