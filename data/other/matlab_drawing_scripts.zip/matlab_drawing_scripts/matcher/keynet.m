function [matches,ttime]=keynet(p_im1,p_im2)

tstart=tic;
py_env=['export LD_LIBRARY_PATH= && source ' getenv('HOME') '/python_env/bin/activate'];

to_run=[py_env ' && cd keynet && python ./keynet.py --input_1st ' pwd filesep p_im1 ' --input_2nd ' pwd filesep p_im2 ' --output_file ../keynet_tmp.mat'];
system(to_run);
load('keynet_tmp.mat');
delete('keynet_tmp.mat');

matches=[kpt1 kpt2];
ttime=toc(tstart);