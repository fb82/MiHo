from copy import deepcopy
import  os
import sys
from PIL import Image
import numpy as np
import torch.nn as nn
import torch
import argparse
from glob import glob
import h5py
import json
from torch import tensor
from tqdm import tqdm
import kornia as K
import kornia.feature as KF
from kornia_moons.feature import *
import cv2
import warnings

def deaffinize_laf(laf):
    xy = KF.laf.get_laf_center(laf)
    sc = KF.laf.get_laf_scale(laf)
    ori = KF.laf.get_laf_orientation(laf)
    return KF.laf.laf_from_center_scale_ori(xy, sc, ori)
def load_fabio_h5(filename):   
    '''Loads dictionary from hdf5 file'''
    dict_to_load = {}    
    def visitor_func(name, node):
        if isinstance(node, h5py.Dataset):
            vname=name[:-4]
            dict_to_load[vname]=np.asarray(node)
            return        
    with h5py.File(filename, 'r') as f:
        f.visititems(visitor_func)    
    return dict_to_load

def get_lafs_and_descriptors(img, harrisz_kpts,
                             kornia_descriptor,
                             ori,
                             aff,
                             aff_string = 'def',
                             mrSize=1.0,
                             num_feats = 2048, device=torch.device('cuda')):
    # We will not train anything, so let's save time and memory by no_grad()
    with torch.no_grad():
        timg = K.image_to_tensor(img, False).float()/255.
        timg = timg.to(device)
        timg = K.color.rgb_to_grayscale(timg)
        # timg = K.color.rgb_to_grayscale(K.image_to_tensor(img, False))/255.
        # timg = timg.to(device)
        hz_pt = torch.from_numpy(harrisz_kpts).float()
        lafs = KF.laf.ellipse_to_laf(hz_pt[None])
        lafs[0,:,0,0] = hz_pt[:,2] * mrSize
        lafs[0,:,0,1] = hz_pt[:,3] * mrSize
        lafs[0,:,1,0] = hz_pt[:,3] * 0
        lafs[0,:,1,1] = hz_pt[:,4] * mrSize
        lafs = lafs.to(timg.device)
        # border image changed from 5 to 10 !!!
        good_lafs_mask = KF.laf.laf_is_inside_image(lafs, timg, 10)
        # all taken!!!
        # good_lafs_mask[:] = True 
        good_lafs = lafs[good_lafs_mask][None]
        if aff_string == 'def':
            out_lafs = good_lafs
        elif aff_string == 'no':
            out_lafs = deaffinize_laf(good_lafs)
        elif aff_string == 'affnet':
            out_lafs = deaffinize_laf(good_lafs)
            out_lafs = aff(out_lafs,timg)            
        elif aff_string == 'orinet_affnet':
            out_lafs = deaffinize_laf(good_lafs)
            out_lafs = ori(aff(out_lafs,timg),timg)
        else:
            raise ValueError('Unknown affine str')
        out_lafs = out_lafs[:,:num_feats]
        # We will estimate affine shape of the feature and re-orient the keypoints with the OriNet
        patches = KF.extract_patches_from_pyramid(timg,out_lafs, 32)
        B, N, CH, H, W = patches.size()
        # Descriptor accepts standard tensor [B, CH, H, W], while patches are [B, N, CH, H, W] shape
        # So we need to reshape a bit :) 
        descs = kornia_descriptor(patches.view(B * N, CH, H, W)).view(B * N, -1)
    return out_lafs, descs.detach().cpu().numpy(), good_lafs_mask[0].detach().cpu().numpy()

if __name__ == '__main__':
    warnings.filterwarnings("ignore", category=DeprecationWarning)     
    parser = argparse.ArgumentParser("Get descriptors for HarrisZ")
    parser.add_argument("--num_keypoints", type=int, default=8000, help='Number of keypoints')
    parser.add_argument("--mrsize", type=float, default=1.0)
    parser.add_argument("--patchsize", type=float, default=32)
    parser.add_argument("--base", type=bool, default=False)
    parser.add_argument("--base_after_desc", type=bool, default=False)
    parser.add_argument("--affine", type=str, default="affnet", choices=["def", "no", "affnet", "orinet_affnet"])
    parser.add_argument("--descriptor", type=str, default='hardnet8', help='hardnet8, hardnet, sift, rootsift, tfeat, sosnet')
    parser.add_argument("--save_path", type=str, required=True, help='Path to store the features')
    parser.add_argument("--hz_file", type=str, required=True)
    args = parser.parse_args()
    kps_all = load_fabio_h5(args.hz_file)

    PS = args.patchsize
    device = torch.device('cpu')
#   try:
#       if torch.cuda.is_available():
#           device = torch.device('cuda')
#   except:
#       print ('CPU mode')
    if args.descriptor.lower() == 'sift':
        descriptor = KF.SIFTDescriptor(PS, rootsift=False)
    elif args.descriptor.lower() == 'rootsift':
        descriptor = KF.SIFTDescriptor(PS, rootsift=True)
    elif args.descriptor.lower() == 'hardnet':
        PS = 32
        descriptor = KF.HardNet(True)
    elif args.descriptor.lower() == 'hardnet8':
        PS = 32
        descriptor = KF.HardNet8(True)        
    elif args.descriptor.lower() == 'sosnet':
        PS = 32
        descriptor = KF.SOSNet(True)
    elif args.descriptor.lower() == 'tfeat':
        PS = 32
        descriptor = KF.TFeat(True)
    else:
        raise ValueError('Unknown descriptor')
    descriptor = descriptor.to(device)
    # print (device)
    descriptor.eval()
    aff_est = KF.LAFAffNetShapeEstimator(True).to(device)
    orienter = KF.LAFOrienter(32, angle_detector=KF.OriNet(True)).to(device)
    orienter.eval()
    aff_est.eval()
    NUM_KP = args.num_keypoints
    images = kps_all.keys()
    num_kp = []
    
    if not os.path.isdir('{}'.format(args.save_path)):
        os.makedirs('{}'.format(args.save_path))    
    f_kp=h5py.File('{}/keypoints.h5'.format(args.save_path), 'w')
    f_desc=h5py.File('{}/descriptors.h5'.format(args.save_path), 'w')
    f_score=h5py.File('{}/scores.h5'.format(args.save_path), 'w')
    f_ang=h5py.File('{}/angles.h5'.format(args.save_path), 'w')
    f_scale=h5py.File('{}/scales.h5'.format(args.save_path), 'w')
    for fn in images: # tqdm(images):
        key = os.path.splitext(os.path.basename(fn))
        key_ext = key[1]
        key = key[0]
        im = cv2.cvtColor(cv2.imread(fn), cv2.COLOR_BGR2RGB)
        hz_kpts = kps_all[fn].T
        if args.base:
            hz_kpts_base = kps_all[fn+'_kpt_base'].T
            hz_kpts[:,:2] = deepcopy(hz_kpts_base[:,:2])
        lafs, descs, mask = get_lafs_and_descriptors(im, hz_kpts,
                     descriptor,
                     orienter,
                     aff_est,
                     aff_string = args.affine,
                     mrSize=args.mrsize,
                     num_feats = NUM_KP, device=device)
        if args.base_after_desc:
            # print ("Base after desc")
            hz_kpts_base = torch.from_numpy(deepcopy(kps_all[fn+'_kpt_base'].T)).float()
            aux_base = hz_kpts_base[mask,:2]                    
            lafs[:,:,:,2] = aux_base[:NUM_KP,:].unsqueeze(0)
        kpts = opencv_kpts_from_laf(lafs)
        keypoints = np.array([(x.pt[0], x.pt[1]) for x in kpts ]).reshape(-1, 2)
        scales = np.array([x.size for x in kpts ]).reshape(-1, 1)
        angles = np.array([x.angle for x in kpts ]).reshape(-1, 1)
        responses = np.array([1+x.response for x in kpts ]).reshape(-1, 1)
        
        f_kp.create_dataset(fn,data=keypoints,compression="gzip",compression_opts=9)
        f_desc.create_dataset(fn,data=descs,compression="gzip",compression_opts=9)
        f_score.create_dataset(fn,data=responses,compression="gzip",compression_opts=9)
        f_ang.create_dataset(fn,data=angles,compression="gzip",compression_opts=9)
        f_scale.create_dataset(fn,data=scales,compression="gzip",compression_opts=9)        
        num_kp.append(len(keypoints))
    # print('Finished processing -> {} features/image'.format(np.array(num_kp).mean()))
