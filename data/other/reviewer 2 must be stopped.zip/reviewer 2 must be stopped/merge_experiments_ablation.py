import sys, os
import numpy as np
import shutil


def csv_write(lines, save_to='nameless.csv'):

    with open(save_to, 'w') as f:
        for l in lines:
            f.write(';'.join(l) + '\n')   

def csv_read(load_from='nameless.csv'):

    aux = [csv_line.split(';') for csv_line in  open(load_from, 'r').read().splitlines()]
    to_fuse = max([idx for idx, el in enumerate([s.startswith('pipe_module') for s in aux[0]]) if el == True]) + 1

    return aux, to_fuse

folder_list = sorted([res_dir for res_dir in os.listdir('new_data_ablation') if res_dir[:4] == 'res_'])

matcher_list = [
    'res_aliked',
    'res_dedodev2',
    'res_disk',
    'res_keynetaffnethardnet',
    'res_sift',
    'res_superpoint',
    'res_mast3r',
    'res_loftr',
    'res_roma',
    ]

dataset_list = [
    'fundamental_and_essential_megadepth',
    'fundamental_and_essential_scannet',
    'homography_planar',
    'fundamental_and_essential_imc_phototourism'
    ]


join_dir = 'join_res'

os.makedirs(os.path.join('new_data_ablation',join_dir,'res'), exist_ok=True)

for mi in matcher_list:    
    for di in dataset_list:
        to_fuse_max = 4
        # to_fuse_max = 0
        # for fn, fi in enumerate(folder_list):
        #     dd = os.listdir(os.path.join('new_data_ablation',fi,'res'))
        #     for nn in dd:
        #         if nn.startswith(mi) and nn.endswith(di+'.csv'):
        #             _, to_fuse = csv_read(os.path.join('new_data_ablation',fi,'res',nn))
        #             to_fuse_max = max(to_fuse_max, to_fuse)

        is_first = True
        was_first = True
        data = []
        for fn, fi in enumerate(folder_list):
            dd = os.listdir(os.path.join('new_data_ablation',fi,'res'))
            for nn in dd:
                if nn.startswith(mi) and nn.endswith(di+'.csv'):
                    data_, to_fuse = csv_read(os.path.join('new_data_ablation',fi,'res',nn))

                    if 'keypt2subpx' in data_[1][0]:
                        to_fuse += 1

                    if is_first:
                        is_first = False
                    else:
                        data_ = data_[1:]
                    
                    for line in data_:                        
                        if 'keypt2subpx' in line[0]:
                            line = [line[0].replace('keypt2subpx_', '')] +  ['keypt2subpx'] + line[1:]
                        
                        # if not was_first:
                        #     line = line[:to_fuse] + (['' ] * (to_fuse_max - to_fuse)) + line[to_fuse:]
                        # else:
                        #     line = ['pipe_module' + str(li) for li in range(to_fuse_max)] + line[to_fuse:]

                        if not was_first:
                            line = [line[0]] + [str(fn)] + line[1:to_fuse] + (['' ] * (to_fuse_max - to_fuse)) + line[to_fuse:]
                        else:
                            line = ['pipe_module' + str(li) for li in range(to_fuse_max+1)] + line[to_fuse:]
                
                        was_first = False
                        
                        data.append(line)

        csv_write(data, os.path.join('new_data_ablation',join_dir,'res',mi+'_'+di+'.csv'))        

