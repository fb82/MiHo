from PIL import Image
import cv2
import numpy as np
import torch
import gdown
import tarfile
import zipfile
import os
import warnings
import _pickle as cPickle
import bz2
import shutil
import csv
import time

from matplotlib import colormaps
import matplotlib.pyplot as plt

def decompress_pickle(file):
    data = bz2.BZ2File(file, 'rb')
    data = cPickle.load(data)
    return data

def plt_data(fname, t, lg, tofile):
    data = decompress_pickle(fname)

    bins = []
    d1 = []
    d2 = []
    d12 = []
    nn = []
    
    for i in data.keys():
        bins.append(data[i]['hist']['bins'])
        d1.append(data[i]['hist']['d1'])
        d2.append(data[i]['hist']['d2'])
        d12.append(data[i]['hist']['d12'])
        nn.append(data[i]['hist']['n'])
    
    bins = bins[0]
    bins = (bins[:-1]+bins[1:])/2
    d1 =np.stack(d1)
    d2 =np.stack(d2)
    d12 =np.stack(d12)
    
    ln = ['-', '--', '-.', ':']
    
    fig, ax = plt.subplots()
    plt.title(t)
    plt.xlabel("max epipolar error (px)")
    plt.ylabel("average number of matches")
    for i in range(d1.shape[0]):
        ax.plot(bins, d12[i] / nn[i], ln[i])
    ax.legend([lg, '+MOP+MiHo', '+NCC', '+MAGSAC'])
    
    plt.savefig(tofile)


def plt_data_diff(fname, t, lg, tofile):
    data = decompress_pickle(fname)
   
    for i in data.keys():
        if 'mean' in data[i]['hist'].keys():        
            bins = data[i]['hist']['bins']
            mean_ = data[i]['hist']['mean']
            median_ = data[i]['hist']['median']
            min_ = data[i]['hist']['min']
            max_ = data[i]['hist']['max']
            std_ = data[i]['hist']['std']
    
            bins = (bins[:-1]+bins[1:])/2
        
            fig, ax = plt.subplots()
            plt.title(t)
            plt.xlabel("max epipolar error (px)")
            plt.ylabel("average number of matches increment with NCC")
            ax.plot(np.asarray([bins[0], bins[-2]]), np.asarray([0, 0]), ':')
#           ax.plot(bins, min_)
#           ax.plot(bins, max_)
#           ax.plot(bins, -std_, '--')
#           ax.plot(bins, std_, '--')
            ax.plot(bins, mean_)
            ax.plot(bins, median_)
            ax.plot(bins, mean_-std_, '--')
            ax.plot(bins, mean_+std_, '--')
            ax.legend(['0', '$\mu$', '$\mu_e$', '$\mu-\sigma$', '$\mu+\sigma$'])
#           ax.legend(['0', 'std', 'mean'])
#           ax.legend(['0', 'min', 'max', '-std', 'std', 'mean'])
    
   
            plt.savefig(tofile)

plt_data("../bench_data_test/res/res_superpoint_lightglue_upright_true_nfeat_8000_resize_1024_fundamental_megadepth.pbz2", 'MegaDepth', 'SP+LG+', 'splg_megadepth.svg')
plt_data("../bench_data_test/res/res_superpoint_lightglue_upright_true_nfeat_8000_resize_1024_fundamental_scannet.pbz2", 'ScanNet', 'SP+LG+', 'splg_scannet.svg')
plt_data("../bench_data_test/res/res_superpoint_lightglue_upright_true_nfeat_8000_resize_1024_homography_planar.pbz2", 'Planar', 'SP+LG+', 'splg_planar.svg')

plt_data("../bench_data_test/res/res_loftr_outdoor_true_upright_true_fundamental_megadepth.pbz2", 'MegaDepth', 'LoFTR+', 'loftr_megadepth.svg')
plt_data("../bench_data_test/res/res_loftr_outdoor_true_upright_true_fundamental_scannet.pbz2", 'ScanNet', 'LoFTR+', 'loftr_scannet.svg')
plt_data("../bench_data_test/res/res_loftr_outdoor_true_upright_true_homography_planar.pbz2", 'Planar', 'LoFTR+', 'loftr_planar.svg')

plt_data("../bench_data_test/res/res_keynetaffnethardnet_upright_true_th_0.99_nfeat_8000_fundamental_megadepth.pbz2", 'MegaDepth', 'KeyNet+AffNet+HarNet+NNR+', 'keynet_megadepth.svg')
plt_data("../bench_data_test/res/res_keynetaffnethardnet_upright_true_th_0.99_nfeat_8000_fundamental_scannet.pbz2", 'ScanNet', 'KeyNet+AffNet+HarNet+NNR+', 'keynet_scannet.svg')
plt_data("../bench_data_test/res/res_keynetaffnethardnet_upright_true_th_0.99_nfeat_8000_homography_planar.pbz2", 'Planar', 'KeyNet+AffNet+HarNet+NNR+', 'keynet_planar.svg')

plt_data("../bench_data_test/res/res_sift_upright_true_rootsift_true_th_0.95_nfeat_8000_fundamental_megadepth.pbz2", 'MegaDepth', 'SIFT+NNR+', 'sift_megadepth.svg')
plt_data("../bench_data_test/res/res_sift_upright_true_rootsift_true_th_0.95_nfeat_8000_fundamental_scannet.pbz2", 'ScanNet', 'SIFT+NNR+', 'sift_scannet.svg')
plt_data("../bench_data_test/res/res_sift_upright_true_rootsift_true_th_0.95_nfeat_8000_homography_planar.pbz2", 'Planar', 'SIFT+NNR+', 'sift_planar.svg')

plt_data_diff("../bench_data_test/res/res_superpoint_lightglue_upright_true_nfeat_8000_resize_1024_fundamental_megadepth.pbz2", 'MegaDepth', 'SP+LG+', 'splg_megadepth_diff.svg')
plt_data_diff("../bench_data_test/res/res_superpoint_lightglue_upright_true_nfeat_8000_resize_1024_fundamental_scannet.pbz2", 'ScanNet', 'SP+LG+', 'splg_scannet_diff.svg')
plt_data_diff("../bench_data_test/res/res_superpoint_lightglue_upright_true_nfeat_8000_resize_1024_homography_planar.pbz2", 'Planar', 'SP+LG+', 'splg_planar_diff.svg')

plt_data_diff("../bench_data_test/res/res_loftr_outdoor_true_upright_true_fundamental_megadepth.pbz2", 'MegaDepth', 'LoFTR+', 'loftr_megadepth_diff.svg')
plt_data_diff("../bench_data_test/res/res_loftr_outdoor_true_upright_true_fundamental_scannet.pbz2", 'ScanNet', 'LoFTR+', 'loftr_scannet_diff.svg')
plt_data_diff("../bench_data_test/res/res_loftr_outdoor_true_upright_true_homography_planar.pbz2", 'Planar', 'LoFTR+', 'loftr_planar_diff.svg')

plt_data_diff("../bench_data_test/res/res_keynetaffnethardnet_upright_true_th_0.99_nfeat_8000_fundamental_megadepth.pbz2", 'MegaDepth', 'KeyNet+AffNet+HarNet+NNR+', 'keynet_megadepth_diff.svg')
plt_data_diff("../bench_data_test/res/res_keynetaffnethardnet_upright_true_th_0.99_nfeat_8000_fundamental_scannet.pbz2", 'ScanNet', 'KeyNet+AffNet+HarNet+NNR+', 'keynet_scannet_diff.svg')
plt_data_diff("../bench_data_test/res/res_keynetaffnethardnet_upright_true_th_0.99_nfeat_8000_homography_planar.pbz2", 'Planar', 'KeyNet+AffNet+HarNet+NNR+', 'keynet_planar_diff.svg')

plt_data_diff("../bench_data_test/res/res_sift_upright_true_rootsift_true_th_0.95_nfeat_8000_fundamental_megadepth.pbz2", 'MegaDepth', 'SIFT+NNR+', 'sift_megadepth_diff.svg')
plt_data_diff("../bench_data_test/res/res_sift_upright_true_rootsift_true_th_0.95_nfeat_8000_fundamental_scannet.pbz2", 'ScanNet', 'SIFT+NNR+', 'sift_scannet_diff.svg')
plt_data_diff("../bench_data_test/res/res_sift_upright_true_rootsift_true_th_0.95_nfeat_8000_homography_planar.pbz2", 'Planar', 'SIFT+NNR+', 'sift_planar_diff.svg')
